#include "defs.h"
#include "MarkovGame.h"
#include "gameWriter.h"
#include "GameEngine.h"
#include "MatrixEngine.h"
#include "MazeEngine.h"
#include "GridWarEngine.h"
#include "LEGOEngine.h"
#include "Player.h"
#include "Xprt.h"
#include "jefe++.h"
#include "jefe.h"
#include "Preventer.h"
#include "rndmPlyr.h"
#include "clientAgent.h"
#include "CFR.h"
#include "client_socket.h"
#include "delayer.h"
#include "RL.h"

void runGame(double ***M, int A[2], int len, char partido[1024], char name[1024], int me_o, char host[1024], int addport);
Player *createPlayer(int me, char partido[1024], char name[1024]);

double ***readPayoffMatrixFromFile(int _A[2], char *game);
void cleanPayoffMatrix(double ***_M, int _A[2]);
void printGame(int _A[2], double ***_M);

GameEngine *ge;

int speaker = -1;

bool cheapTalk;

char stringToCommunicate[1024];

bool delaysOn = false;


/* ****************************************************
//
//	./Solver <game> <iters> <playertype> <me> <hostIP> <addport> <cheaptalk>
//
// **************************************************** */
int main(int argc, char** argv) {
    if (argc < 6) {
        printf("Not enough commandline parameters\n");
        exit(1);
    }

	srand(time(NULL));

	double ***M;
	int A[2];
    M = readPayoffMatrixFromFile(A, argv[1]);
    int iters = atoi(argv[2]);
    printf("iters = %i\n", iters);
    int me_o = atoi(argv[4]);
    printf("I am %i\n", me_o);
    
    int addport = atoi(argv[6]);
    if (argc > 7) {
        if (!strcmp(argv[7], "cheaptalk")) {
            cheapTalk = true;
            printf("cheapTalk = true\n");
        }
    }

    int numSamps = 1;
    for (int i = 0; i < numSamps; i++) {
        runGame(M, A, iters, argv[1], argv[3], me_o, argv[5], addport+i*3);
        
        //if (me_o == 0)
        //    usleep(1000000);
        //else
        //    usleep(1500000);
    }
    
    
	cleanPayoffMatrix(M, A);
	
    
	return 0;
}



void runGame(double ***M, int A[2], int len, char partido[1024], char name[1024], int me_o, char host[1024], int addport) {
	int i;
	int act;//, *acts = new int[2];
	char buf[10000];
    double payoffs[2];

    char dummy[1024];

	Player *player = createPlayer(me_o, partido, name);
    ClientSocket *cs = new ClientSocket(host, 3000+me_o+addport);
    
    if (cheapTalk)
        cs->SendMessage(name, strlen(name));
    else {
        char nombre2[1024];
        sprintf(nombre2, "%s-", name);
        cs->SendMessage(nombre2, strlen(nombre2));
    }
    
    if (player == NULL) {
        if (player != NULL)
            delete player;
        return;
    }
    
    cs->ReadMessage(buf);
    
    strcpy(stringToCommunicate, "");
    
    //gettimeofday(&eltiempo, NULL);
    //sTime = eltiempo.tv_sec + (eltiempo.tv_usec / 1000000.0);
    
    double ttalk = (double)(rand() % 10);
    double tact[2];
    int amount;
    tact[0] = tact[1] = (double)(rand() % 10);
    
	for (i = 0; i < len; i++) {
    
        printf("\nRound: %i\n", i);
        
        //player->select();
    
        //printf("stringToCommunicate: %s\n", stringToCommunicate);
        
        ge->initRound();
        player->Reset();
        
        if (cheapTalk) {
            // delay cheap talk
            //printf("-------------- stringToCommunicate length: %i\n", (int)strlen(stringToCommunicate));
            if (ttalk < ((int)strlen(stringToCommunicate)))
                ttalk = (int)strlen(stringToCommunicate);
            
            if (ttalk > 20.0)
                ttalk = 20.0;
            
            amount = (int)(ttalk * 1000000);
            
            if (delaysOn)
                usleep(amount);
            
            strcat(stringToCommunicate, "$ 0.000000");
            //strcat(stringToCommunicate, "$");
            printf("sending: %s\n", stringToCommunicate);
            cs->SendMessage(stringToCommunicate, strlen(stringToCommunicate));
        
            cs->ReadMessage(buf);
            
            //strcat(buf, " 0.000000");
            //printf("read msg: %s\n", buf);

            ttalk = player->processCheapTalk(buf, true); // Note: change second parameter to false to make player not listen to cheaptalk of others
        }
        
        //printf("cheapTalk done\n");

        strcpy(stringToCommunicate, "");
    
        //printf("a"); fflush(stdout);
        
        if (tact[1-me_o] > 20.0)
            amount = 20000000;
        else
            amount = (int)(tact[1-me_o] * 1000000);
        
        if (delaysOn)
            usleep(amount);
    
		act = player->Move(ge);
        sprintf(buf, "%i $ 0.000000", act);
        cs->SendMessage(buf, strlen(buf));

        //printf("c"); fflush(stdout);
        
        // read the result
        cs->ReadMessage(buf);
        //printf("message: %s\n", buf);
        
        //strcat(buf, " 0.000000 0.000000");
        
        sscanf(buf, "%i %i %s %lf %lf", &(ge->actions[0]), &(ge->actions[1]), dummy, &(tact[0]), &(tact[1]));
        //printf("%i: actions: %i %i\n", i, acts[0], acts[1]); fflush(stdout);
        //printf("he took %lf seconds\n", tact[1-me_o]);
        
        if (ge->actions[me_o] != act) {
            printf("Server isn't properly listenting to me.  I QUIT!!!\n");
            exit(1);
        }
        
        ge->MoveAgents();
        
        //printf("acting done\n");
        //printf("t"); fflush(stdout);
        
        //printf("acts: %i %i\n", ge->actions[0], ge->actions[1]);
        payoffs[0] = M[0][ge->actions[0]][ge->actions[1]];
        payoffs[1] = M[1][ge->actions[0]][ge->actions[1]];
		player->moveUpdate(ge, ge->actions, payoffs);

        //printf("e"); fflush(stdout);
        
        player->roundUpdate();
        
        //printf("d"); fflush(stdout);
        
	}
    
    printf("finished\n");
    
    //cs->ReadMessage(buf);
    //printf("%s\n", buf);

    //usleep(1000000);

    delete cs;
	delete player;
}



Player *createPlayer(int me, char partido[1024], char name[1024]) {
    char buf[1024], fnombre[1024];

    strcpy(buf, partido);
    if (!strcmp(buf, "prisoners"))
        strcpy(buf, "pd");
    
    if ((!strcmp(buf, "pd")) || (!strcmp(buf, "chicken")) || (!strcmp(buf, "chicken2")) || (!strcmp(buf, "blocks")) || (!strcmp(buf, "blocks2")) || (!strcmp(buf, "shapleys")) || (!strcmp(buf, "tricky"))) {
        ge = new MatrixEngine();
    }
    else {
        printf("game not found\n");
        exit(1);
    }
    
    sprintf(fnombre, "MG_%s.txt", buf);
    
    printf("asfkjasldfjas %s\n", fnombre);
    
    Player *pl = NULL;
    
    if (!strcmp(name, "maxmin")) {
        printf("player: maxmin\n");
        pl = new Xprt(me, new MarkovGame(fnombre), buf);
    }
    else if (!strcmp(name, "mbrl")) {
        printf("player: mbrl\n");
        pl = new Xprt(me, new MarkovGame(fnombre), buf);
    }
    else if (!strcmp(name, "umbrl")) {
        printf("player: umbrl\n");
        strcpy(buf, "umbrl");
        pl = new Xprt(me, new MarkovGame(fnombre), buf, true);
    }
    else if (!strcmp(name, "folk")) {
        printf("player: folk\n");
        strcpy(buf, "folk");
        pl = new Xprt(me, new MarkovGame(fnombre), buf);
    }
    else if (!strcmp(name, "bully")) {
        printf("player: bully\n");
        strcpy(buf, "bully");
        pl = new Xprt(me, new MarkovGame(fnombre), buf);
    }
    else if (!strcmp(name, "S++")) {
        printf("player: mega-S++\n");
        pl = new jefe_plus("S++", me, new MarkovGame(fnombre), 0.99, EMOTION_PLANNER_TYPE, me);
        speaker = me;
    }
    else if (!strcmp(name, "megaExp3")) {
        printf("player: megaExp3\n");
        pl = new jefe("exp3", me, new MarkovGame(fnombre), 500);
    }
    else if (!strcmp(name, "bouncer")) {
        printf("player: Preventer\n");
        pl = new Preventer(me, new MarkovGame(fnombre), 0.0);  // 0.2
    }
    else if (!strcmp(name, "cfr")) {
        printf("player: CFR\n");
        pl = new CFR(me, new MarkovGame(fnombre), 40, partido, false);
    }
    else if (!strcmp(name, "cfru")) {
        printf("player: CFR\n");
        pl = new CFR(me, new MarkovGame(fnombre), 40, partido, true);
    }
    else if (!strcmp(name, "friend")) {
        printf("player: Friend-VI\n");
        pl = new RL(me, new MarkovGame(fnombre), FRIENDVI);
    }
    else {
        printf("player type %s not found\n", name);
        exit(1);
    }
    
    return pl;
}

double ***readPayoffMatrixFromFile(int _A[2], char *game) {
	double ***_M;
    
	char filename[1024];
	sprintf(filename, "..//..//games//%s.txt", game);
	
	FILE *fp = fopen(filename, "r");
	if (fp == NULL) {
		// check in an alternate directory before giving up
		sprintf(filename, "..//games//%s.txt", game);
		fp = fopen(filename, "r");
		if (fp == NULL) {
			printf("file %s not found\n", filename);
			exit(1);
		}
	}

	fscanf(fp, "%i", &(_A[0]));
	fscanf(fp, "%i", &(_A[0]));
	fscanf(fp, "%i", &(_A[1]));
	
	int i, j;
	_M = new double**[2];
	for (i = 0; i < 2; i++) {
		_M[i] = new double*[_A[0]];
		for (j = 0; j < _A[0]; j++)
			_M[i][j] = new double[_A[1]];
	}

	for (i = 0; i < _A[1]; i++) {
		for (j = 0; j < _A[0]; j++) {
			fscanf(fp, "%lf %lf", &(_M[0][j][i]), &(_M[1][j][i]));
		}
	}

    printGame(_A, _M);
    
	return _M;
}

void cleanPayoffMatrix(double ***_M, int _A[2]) {
	int i, j;
	
	for (i = 0; i < 2; i++) {
		for (j = 0; j < _A[0]; j++)
			delete _M[i][j];
		delete _M[i];
	}
	delete _M;
}

void printGame(int _A[2], double ***_M) {
    int i, j;
    
    printf("\n   |      ");
    
    for (i = 0; i < _A[1]; i++)
        printf("%i      |      ", i);
    printf("\n");
    for (i = 0; i < _A[0]; i++) {
        printf("--------------------------------------\n %i | ", i);
        for (j = 0; j < _A[1]; j++) {
            printf("%.2lf , %.2lf | ", _M[0][i][j], _M[1][i][j]);
        }
        printf("\n");
    }
    printf("--------------------------------------\n\n");
}



