./Solver prisoners all friend friend 500
./Solver prisoners all friend maxmin 500
./Solver prisoners all friend folk 500
./Solver prisoners all friend bully 500
./Solver prisoners all friend bouncer 500
./Solver prisoners all friend mbrl 500
./Solver prisoners all friend umbrl 500
./Solver prisoners all friend cfru 500
./Solver prisoners all friend megaS++ 500
./Solver prisoners all friend megaExp3 500

./Solver prisoners all maxmin maxmin 500
./Solver prisoners all maxmin folk 500
./Solver prisoners all maxmin bully 500
./Solver prisoners all maxmin bouncer 500
./Solver prisoners all maxmin mbrl 500
./Solver prisoners all maxmin umbrl 500
./Solver prisoners all maxmin cfru 500
./Solver prisoners all maxmin megaS++ 500
./Solver prisoners all maxmin megaExp3 500

./Solver prisoners all folk folk 500
./Solver prisoners all folk bully 500
./Solver prisoners all folk bouncer 500
./Solver prisoners all folk mbrl 500
./Solver prisoners all folk umbrl 500
./Solver prisoners all folk cfru 500
./Solver prisoners all folk megaS++ 500
./Solver prisoners all folk megaExp3 500

./Solver prisoners all bully bully 500
./Solver prisoners all bully bouncer 500
./Solver prisoners all bully mbrl 500
./Solver prisoners all bully umbrl 500
./Solver prisoners all bully cfru 500
./Solver prisoners all bully megaS++ 500
./Solver prisoners all bully megaExp3 500

./Solver prisoners all bouncer bouncer 500
./Solver prisoners all bouncer mbrl 500
./Solver prisoners all bouncer umbrl 500
./Solver prisoners all bouncer cfru 500
./Solver prisoners all bouncer megaS++ 500
./Solver prisoners all bouncer megaExp3 500

./Solver prisoners all mbrl mbrl 500
./Solver prisoners all mbrl umbrl 500
./Solver prisoners all mbrl cfru 500
./Solver prisoners all mbrl megaS++ 500
./Solver prisoners all mbrl megaExp3 500

./Solver prisoners all umbrl umbrl 500
./Solver prisoners all umbrl cfru 500
./Solver prisoners all umbrl megaS++ 500
./Solver prisoners all umbrl megaExp3 500

./Solver prisoners all cfru cfru 500
./Solver prisoners all cfru megaS++ 500
./Solver prisoners all cfru megaExp3 500

./Solver prisoners all megaS++ megaS++ 500
./Solver prisoners all megaS++ megaExp3 500

./Solver prisoners all megaExp3 megaExp3 500
