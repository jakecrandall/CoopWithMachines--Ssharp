#include "Leader.h"

extern bool theRealRobot;
extern bool sleepNeeded;
extern bool doTheSpecify;
extern bool yaDicho, yaDicho2;

Leader::Leader() {
    printf("incomplete Leader constructor");
    exit(1);
}

Leader::Leader(int _commType, bool _alternate, bool _bully) {
    commType = _commType;
    alternate = _alternate;
    bully = _bully;
    
    count = 0;
    lowered = false;
}

Leader::~Leader() {
}

//void Leader::Introduce(int currentExpert, int previousExpert, char ja_1[1024], char ja_2[1024], bool myTurn, bool alter, bool _iaccept, char stringToCommunicate[1024]) {
void Leader::Introduce(bool newExpert, bool _forgiveness, char ja_1[1024], char ja_2[1024], bool myTurn, bool alter, bool _iaccept, bool _notrust, bool _notfairo, char stringToCommunicate[1024]) {
    char buf[1024];
    
    printf("---------------- Leader Introduce (%i) ------------------\n", _notfairo);
    
    if (_iaccept) {
        sprintf(buf, "%i;", IACCEPT);
        strcpy(stringToCommunicate, buf);
        //strcat(stringToCommunicate, buf);
    }
    else if (_notrust && !yaDicho) {
        sprintf(buf, "%i;%i;", UNACCEPTABLE, NOTRUST);
        strcat(stringToCommunicate, buf);
        yaDicho = true;
    }
    else if (_notfairo && !yaDicho) {
        sprintf(buf, "%i;%i;", UNACCEPTABLE, NOTFAIR);
        strcat(stringToCommunicate, buf);
        yaDicho = true;
    }
    
    //if ((currentExpert != previousExpert)) { // && !bully) {
    if (newExpert || _forgiveness) {
        if (commType == EMOTION_PLANNER_TYPE) {
            //sprintf(buf, "%s ", intros[0]);
            if (!alternate && !yaDicho2) {
                sprintf(buf, "%i %s;", LETS_COOP, ja_1);
                strcat(stringToCommunicate, buf);
            }
            else {
                //sprintf(buf, "%s ", intros[1]);
                printf("Should say to take turns, but if I've already said it ... ");
                if (!yaDicho2) {
                    sprintf(buf, "%i %s %s;", TAKE_TURNS, ja_1, ja_2);
                    strcat(stringToCommunicate, buf);
                }
               
                if (doTheSpecify) {
                    if (myTurn)
                        sprintf(buf, "%i %s;", SPECIFY, ja_2);
                    else
                        sprintf(buf, "%i %s;", SPECIFY, ja_1);
                    strcat(stringToCommunicate, buf);
                    
                }
            }
            //sprintf(buf, "%s ", intros[3]);
            if (!yaDicho2) {
                sprintf(buf, "%i;", COMPLY_OR_ELSE);
                strcat(stringToCommunicate, buf);
            }
        }
        
        //printf("************* Leader: set the dicho = true\n");
        yaDicho2 = true;
        
        if (newExpert)
            count = 0;
    }
    else if (alternate && (count < 5) && alter) {
        if (commType == EMOTION_PLANNER_TYPE) {
            // I NEED TO WORK ON THIS
            
            if (doTheSpecify) {
                if (myTurn)
                    sprintf(buf, "%i %s;", SPECIFY, ja_2);
                else
                    sprintf(buf, "%i %s;", SPECIFY, ja_1);
                strcat(stringToCommunicate, buf);
                
                //printf("************* Leader: set the dicho = true\n");
                //yaDicho = true;
            }
        }
    }

    //printf("count = %i\n", count);
    
    if ((count == 5) && (commType == EMOTION_PLANNER_TYPE)) {
        //sprintf(buf, "%s ", intros[11]);
        sprintf(buf, "%i;", SWEET);
        strcat(stringToCommunicate, buf);
    }
    
    count = count + 1;
}

void Leader::roundUpdate(bool happyRound, bool forgiveness, char stringToCommunicate[1024]) {
    char buf[1024];
    
    lowered = false;
    if (happyRound && (count < 4)) {
        //sprintf(buf, "%s ", happythoughts[rand() % 4]);
        if (!yaDicho && !yaDicho2) {
            sprintf(buf, "%i;", EXCELLENT);
            strcat(stringToCommunicate, buf);
        }
    }
    
    if (forgiveness) {
        if (commType == EMOTION_PLANNER_TYPE) {
            sleepNeeded = true;
            
            sprintf(buf, "%i;", FORGIVENESS);
            strcat(stringToCommunicate, buf);
            
            //sprintf(buf, "%i;", DOBETTER);
            //strcat(stringToCommunicate, buf);
        }
        
        //if (alternate) {
            if (count > 2)
                count = 2;
        //}
    }
}

void Leader::moveEvent(bool shoulda, char shouldaMsg[1024], bool _heLowered, bool _guilty, bool forgiveness, bool theresmore, char stringToCommunicate[1024]) {
    char buf[1024];
    
    //printf("moveEvent: %i %i\n", (int)_guilty, _heLowered);
    
    if (shoulda) {
        if (_guilty) {
            //sprintf(buf, "%i;%i %c;%i;", BETRAYED+(rand() % 2), I_TRUSTED, shouldaMsg[0], YOULL_PAY+(rand() % 2));
            if (rand() % 2)
                sprintf(buf, "%i;%i;", BETRAYED, YOULL_PAY);
            else
                sprintf(buf, "%i;%i;", CURSE_YOU, YOULL_PAY);
            //printf("guilty\n");
            if (count > 2)
                count = 2;
        }
        else {
            //sprintf(buf, "%i;%i %c;", BETRAYED+(rand() % 2), I_TRUSTED, shouldaMsg[0]);
            //sprintf(buf, "%i;", BETRAYED);
            if (rand() % 2)
                sprintf(buf, "%i;", BETRAYED);
            else
                sprintf(buf, "%i;", CURSE_YOU);
            //printf("not guilty\n");
            if (count > 2)
                count = 2;
        }


        strcat(stringToCommunicate, buf);
        
        sleepNeeded = true;
    }
    
    //printf("heLowered = %i; guilty = %i\n", (int)_heLowered, (int)_guilty);
    
    //if (!lowered && _heLowered && _guilty) {
    if (_heLowered && _guilty) {
        sleepNeeded = true;

        //sprintf(buf, "%s ", inyourface[rand() % 3]);
        //if (!forgiveness) {
            sprintf(buf, "%i;", INYOURFACE);
            strcat(stringToCommunicate, buf);
        //}
        
        lowered = true;
    }
    
//    if (theresmore) {
//        sprintf(buf, "%i;", THERESMORE);
//        strcat(stringToCommunicate, buf);
//    }
    
    if (_guilty and (count > 2))
        count = 2;
    
}
