#ifndef DEFS_H
#define DEFS_H

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <unistd.h>

#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <fstream>
#include <strings.h>
#include <string>
#include <pthread.h>

#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>

#else
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#endif

// some old constants
#define NUMACTIONS	5
#define STAY		0
#define SENTINAL	-999999
#define MAX_MOVES_PER_ROUND		50

#define NONE    -1
#define UPP     0
#define DOWNN   1
#define RIGHTT  2
#define LEFTT   3

#define CONNECT_PORT    3000

#define EMOTION_TYPE            0
#define EMOTION_PLANNER_TYPE    1

#define COMPLY_OR_ELSE      0
#define IACCEPT             1
#define UNACCEPTABLE        2
#define NOTFAIR             3
#define NOTRUST             4
#define EXCELLENT           5
#define SWEET               6
#define SECOND_CHANCE       7
#define FORGIVENESS         8
#define CHANGE_O_HEART      9
#define DOBETTER            10
#define CURSE_YOU           11
#define BETRAYED            12
#define YOULL_PAY           13
#define INYOURFACE          14
#define LETS_COOP           15
#define SPECIFY             16
#define DONT_PLAY           17
#define TAKE_TURNS          18

#endif