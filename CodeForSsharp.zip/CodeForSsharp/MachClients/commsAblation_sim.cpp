#include "defs.h"

FILE *allFP, *summaryFP, *summaryFP_5;

int getMCoop(const char *game, int a0, int a1) {
    if (!strcmp(game, "prisoners")) {
        if ((a0 == 0) && (a1 == 0))
            return 1;
        else
            return 0;
    }
    else if (!strcmp(game, "chicken2")) {
        if ((a0 == 1) && (a1 == 1))
            return 1;
        else
            return 0;
    }

    else {
        printf("Tenemos un problema!\n");
    }

    return 0;
}

void readEm(const char *game, const char *commCond, const char *commCond2, int trials, int iters) {

    char fnombre[1024];
    int i, j, a0, a1;
    double p0, p1;
    
    for (i = 0; i < trials; i++) {
        sprintf(fnombre, "../newResults/%s_%s/%s_megaS++_megaS++_activity_%i.txt", game, commCond, game, i);
        FILE *fp = fopen(fnombre, "r");

        double sp0, sp1, mcoop, sp0_5, sp1_5, mcoop_5;
        sp0 = sp1 = mcoop = 0.0;
        sp0_5 = sp1_5 = mcoop_5 = 0.0;
        for (j = 0; j < iters; j++) {
            fscanf(fp, "%i %i %lf %lf", &a0, &a1, &p0, &p1);
            sp0 += p0;
            sp1 += p1;
            mcoop += getMCoop(game, a0, a1);
            fprintf(allFP, "%s,%s,%i,%i,%i,%i,%lf,%lf,%i\n", game, commCond2, i, j, a0, a1, p0, p1, getMCoop(game, a0, a1));
            
            sp0_5 += p0;
            sp1_5 += p1;
            mcoop_5 += getMCoop(game, a0, a1);
            if ((j % 5) == 4) {
                fprintf(summaryFP_5, "%s,%s,%i,%i,%lf,%lf,%lf\n", game, commCond2, i, j, sp0_5 / 5.0, sp1_5 / 5.0, mcoop_5 / 5.0);
                sp0_5 = sp1_5 = mcoop_5 = 0.0;
            }
        }

        fprintf(summaryFP, "%s,%s,%i,%i,%lf,%lf,%lf\n", game, commCond2, i, j, sp0 / 50.0, sp1 / 50.0, mcoop / 50.0);

        fclose(fp);
    }
}

int getMCoop(double pay[2][50], int index) {
    double first[2];
    double second[2];
    
    if (index > 0) {
        first[0] = pay[0][index-1] + pay[0][index];
        first[1] = pay[1][index-1] + pay[1][index];
        
        if ((first[0] == 1.4) && (first[1] == 1.4))
            return 1;
    }
    
    if (index < 49) {
        second[0] = pay[0][index] + pay[0][index+1];
        second[1] = pay[1][index] + pay[1][index+1];
        
        if ((second[0] == 1.4) && (second[1] == 1.4))
            return 1;
    }
    
    return 0;
}

void readEm2(const char *game, const char *commCond, const char *commCond2, int trials, int iters) {

    char fnombre[1024];
    int i, j, a0, a1;
    double p0, p1;
    double pay[2][50];
    
    for (i = 0; i < trials; i++) {
        sprintf(fnombre, "../newResults/%s_%s/%s_megaS++_megaS++_activity_%i.txt", game, commCond, game, i);
        FILE *fp = fopen(fnombre, "r");

        for (j = 0; j < iters; j++)
            fscanf(fp, "%i %i %lf %lf", &a0, &a1, &(pay[0][j]), &(pay[1][j]));
        
        fclose(fp);

        sprintf(fnombre, "../newResults/%s_%s/%s_megaS++_megaS++_activity_%i.txt", game, commCond, game, i);
        fp = fopen(fnombre, "r");

        double sp0, sp1, mcoop, sp0_5, sp1_5, mcoop_5;
        sp0 = sp1 = mcoop = 0.0;
        sp0_5 = sp1_5 = mcoop_5 = 0.0;
        for (j = 0; j < iters; j++) {
            fscanf(fp, "%i %i %lf %lf", &a0, &a1, &p0, &p1);
            sp0 += p0;
            sp1 += p1;
            mcoop += getMCoop(pay, j);
            fprintf(allFP, "%s,%s,%i,%i,%i,%i,%lf,%lf,%i\n", game, commCond2, i, j, a0, a1, p0, p1, getMCoop(pay, j));
            
            sp0_5 += p0;
            sp1_5 += p1;
            mcoop_5 += getMCoop(pay, j);;
            if ((j % 5) == 4) {
                fprintf(summaryFP_5, "%s,%s,%i,%i,%lf,%lf,%lf\n", game, commCond2, i, j, sp0_5 / 5.0, sp1_5 / 5.0, mcoop_5 / 5.0);
                sp0_5 = sp1_5 = mcoop_5 = 0.0;
            }
        }

        fprintf(summaryFP, "%s,%s,%i,%i,%lf,%lf,%lf\n", game, commCond2, i, j, sp0 / 50.0, sp1 / 50.0, mcoop / 50.0);

        fclose(fp);
    }
    
}

int main(int argc, char *argv[]) {

    allFP = fopen("../newResults/ablation.csv", "w");
    fprintf(allFP, "Game,Communication,Trial,Round,Action0,Action1,Payoff0,Payoff1,MCoop\n");

    summaryFP = fopen("../newResults/ablation_summary.csv", "w");
    fprintf(summaryFP, "Game,Communication,Trial,Round,Payoff0,Payoff1,MCoop\n");

    summaryFP_5 = fopen("../newResults/ablation_summary_5.csv", "w");
    fprintf(summaryFP_5, "Game,Communication,Trial,Round,Payoff0,Payoff1,MCoop\n");

    readEm("prisoners", "zero", "None", 50, 50);
    readEm("prisoners", "one", "One-Way", 50, 50);
    readEm("prisoners", "two", "Two-Way", 50, 50);
    readEm("chicken2", "zero", "None", 50, 50);
    readEm("chicken2", "one", "One-Way", 50, 50);
    readEm("chicken2", "two", "Two-Way", 50, 50);
    readEm2("blocks2", "zero", "None", 50, 50);
    readEm2("blocks2", "one", "One-Way", 50, 50);
    readEm2("blocks2", "two", "Two-Way", 50, 50);
    
    fclose(allFP);
    fclose(summaryFP);
    fclose(summaryFP_5);

    return 0;
}