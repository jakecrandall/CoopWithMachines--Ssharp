#include "CommAgent.h"

//extern void addMessage(char msg[1024], int _origin, int _lineHeight);

extern char stringToCommunicate[1024];

bool theRealRobot = true;
bool sleepNeeded = false;
extern bool yaDicho, yaDicho2;

CommAgent::CommAgent() {
    printf("incomplete CommAgent constructor\n");
    exit(1);
}

CommAgent::CommAgent(int _commtipo, int port, int _me, bool talkType) {
    commtipo = _commtipo;
    me = _me;
    
    //printf("commAgent\n"); fflush(stdout);

    if (commtipo == ROBOT_TIPO) {
        rserver = new MySocket(port);
        rserver->AcceptEm();
        
        //printf("all set up\n"); fflush(stdout);
    }

    numMessages = 0;
    tipo = talkType;//EMOTION_PLANNER;
    
    bouncer = new Bouncer(tipo);
    br = new Br(tipo);
    pureLead = new Leader(tipo, false, false);
    altLead = new Leader(tipo, true, false);
    bullyLead = new Leader(tipo, false, true);
    pureFollow = new Follower(tipo, false, false);
    altFollow = new Follower(tipo, true, false);
    bullyFollow = new Follower(tipo, false, true);
    
    currentExpert = previousExpert = -1;
    roundDone = false;
    happyExpert = false;
    happyRound = false;
    bothBetter = false;
    theresmore = false;
    myTurn = false;
    currentlyGuilty = false;
    associateDecreased = associateIncreased = false;
    imDecreased = imIncreased = false;
    shoulda = false;
    forgiveness = false;
    iaccept = false;
    notrust = false;
    notfairo = false;
    
    newExpert = false;
    
    notfairCount = distrustCount = 0;
}

CommAgent::~CommAgent() {
    if (commtipo == ROBOT_TIPO)
        delete rserver;
    
    delete pureFollow;
    delete altFollow;
    delete bullyFollow;
    delete br;
    delete bouncer;
    delete pureLead;
    delete altLead;
    delete bullyLead;    
}

void CommAgent::logEvent(int eventType, int value, const char *message) {
    //printf("log an event (%i) ... \n", numMessages);
    //fflush(stdout);
    
    //return;
    
    tipos[numMessages] = eventType;    
    valores[numMessages] = value;
    strcpy(strgs[numMessages], message);
    
    numMessages++;

    //printf("\taddedEvent %i\n", numMessages);

    //printf("logged\n");
    //fflush(stdout);
}


void CommAgent::printRobotMessages(bool silentTreatment) {
    
    //if (commtipo != ROBOT_TIPO)
    //    return;
    
    int i;
    char msg[1024];
    strcpy(msg, "");
    char buf[1024];
    
    //printf("numMessages = %i\n", numMessages); fflush(stdout);
    
    for (i = 0; i < numMessages; i++) {
        if (tipos[i] == MSG_EXPERT) {
            sprintf(buf, "Expert %i ", valores[i]);
            strcat(msg, buf);
        }
        else if (tipos[i] == MSG_EVENT) {
            sprintf(buf, "Event %i ", valores[i]);
            strcat(msg, buf);
        }
        else if (tipos[i] == MSG_ASSESSMENT) {
            sprintf(buf, "Assess %i %s", valores[i], strgs[i]);
            strcat(msg, buf);
        }
        else if (tipos[i] == MSG_STRING) {
            sprintf(buf, "String %i %s ", valores[i], strgs[i]);
            strcat(msg, buf);
        }
        else if (tipos[i] == MSG_ROUND) {
            sprintf(buf, "Round %i ", valores[i]);
            strcat(msg, buf);
        }
        else if (tipos[i] == MSG_JACTION) {
            //printf("************** got to here: %s\n", strgs[i]);
            sprintf(buf, "JAction %s ", strgs[i]);
            strcat(msg, buf);
        }
    }
    
    strcat(msg, "*");
    
    //strcpy(stringToCommunicate, "");
    
    //printf("to parse the message\n"); fflush(stdout);
    
    parseMsg(msg);
    //printf("parsed\n");
    speechActs(silentTreatment);
    
    
    numMessages = 0;
}


void CommAgent::speechActs(bool silentTreatment) {
    // decide if I should speak to him
    
    
    
    bool alter = true;
    if (currentlyGuilty && !forgiveness)
        alter = false;
    
//    if ((currentExpert > 2) && (notrust)) {
//        char buf[1024];
    
//        sprintf(buf, "%i;", NOTRUST);
//        strcat(stringToCommunicate, buf);
//    }

    //printf("\tCurrentExpert = %i\n", currentExpert);
    
    //printf("currentExpert = %i\n", currentExpert);
    if ((currentExpert == 0) && (previousExpert != 0)) {
        char buf[1024];
        sprintf(buf, "%i;", NOTRUST);
        strcat(stringToCommunicate, buf);
    }
    else if ((currentExpert == 1) && (previousExpert < 2)) { // Br
        if (br->first)
            br->Introduce(stringToCommunicate);
        else if (roundDone)
            br->roundUpdate(happyRound, stringToCommunicate);
        
        if (notfairo && !yaDicho) {
            char buf[1024];
            sprintf(buf, "%i;%i;", UNACCEPTABLE, NOTFAIR);
            strcat(stringToCommunicate, buf);
            yaDicho = true;
        }
    }
    else if (currentExpert == 2) { // Bouncer
        if (roundDone) {
            if (newExpert) //currentExpert != previousExpert)
                bouncer->Introduce(stringToCommunicate);
            else {
                bouncer->roundUpdate(happyRound, stringToCommunicate);
            }
        }
    }
    else if (currentExpert == 3) {
        //if (associateDecreased)
        //    printf("helowered\n");
        //else
        //    printf("!!!!Not heLowered\n");
        pureLead->moveEvent(shoulda, shouldaMsg, associateDecreased, currentlyGuilty, forgiveness, theresmore, stringToCommunicate);
        //printf("s2c: %s\n", stringToCommunicate);
        if (roundDone) {
            if (currentExpert == previousExpert) {
                pureLead->roundUpdate(happyRound, forgiveness, stringToCommunicate);
            }
            //pureLead->Introduce(currentExpert, previousExpert, ja_1, ja_2, myTurn, alter, iaccept, stringToCommunicate);
            pureLead->Introduce(newExpert, forgiveness, ja_1, ja_2, myTurn, alter, iaccept, notrust, notfairo, stringToCommunicate);
        }
    }
    else if (currentExpert == 4) {
        altLead->moveEvent(shoulda, shouldaMsg, associateDecreased, currentlyGuilty, forgiveness, theresmore, stringToCommunicate);
        //printf("s2c: %s\n", stringToCommunicate);
        if (roundDone) {
            if (currentExpert == previousExpert) {
                altLead->roundUpdate(happyRound, forgiveness, stringToCommunicate);
            }
            //altLead->Introduce(currentExpert, previousExpert, ja_1, ja_2, myTurn, alter, iaccept, stringToCommunicate);
            altLead->Introduce(newExpert, forgiveness, ja_1, ja_2, myTurn, alter, iaccept, notrust, notfairo, stringToCommunicate);
        }
    }
    else if (currentExpert == 5) {
        bullyLead->moveEvent(shoulda, shouldaMsg, associateDecreased, currentlyGuilty, forgiveness, theresmore, stringToCommunicate);
        //printf("s2c: %s\n", stringToCommunicate);
        if (roundDone) {
            if (currentExpert == previousExpert) {
                bullyLead->roundUpdate(happyRound, forgiveness, stringToCommunicate);
            }
            //bullyLead->Introduce(currentExpert, previousExpert, ja_1, ja_2, myTurn, alter, iaccept, stringToCommunicate);
            bullyLead->Introduce(newExpert, forgiveness, ja_1, ja_2, myTurn, alter, iaccept, notrust, notfairo, stringToCommunicate);
        }
    }
    
    else if (currentExpert == 6) {
        pureFollow->moveEvent(shoulda, shouldaMsg, associateDecreased, currentlyGuilty, stringToCommunicate);
        //printf("s2c: %s\n", stringToCommunicate);
        if (roundDone) {
            if (currentExpert == previousExpert) {
                pureFollow->roundUpdate(happyRound, forgiveness, stringToCommunicate);
            }
            //pureFollow->Introduce(currentExpert, previousExpert, ja_1, ja_2, myTurn, iaccept, stringToCommunicate);
            pureFollow->Introduce(newExpert, forgiveness, ja_1, ja_2, myTurn, iaccept, notrust, notfairo, stringToCommunicate);
        }
    }
    else if (currentExpert == 7) {
        altFollow->moveEvent(shoulda, shouldaMsg, associateDecreased, currentlyGuilty, stringToCommunicate);
        //printf("s2c: %s\n", stringToCommunicate);
        if (roundDone) {
            if (currentExpert == previousExpert) {
                altFollow->roundUpdate(happyRound, forgiveness, stringToCommunicate);
            }
            //altFollow->Introduce(currentExpert, previousExpert, ja_1, ja_2, myTurn, iaccept, stringToCommunicate);
            altFollow->Introduce(newExpert, forgiveness, ja_1, ja_2, myTurn, iaccept, notrust, notfairo, stringToCommunicate);
        }
    }
    else if (currentExpert == 8) {
        bullyFollow->moveEvent(shoulda, shouldaMsg, associateDecreased, currentlyGuilty, stringToCommunicate);
        //printf("s2c: %s\n", stringToCommunicate);
        if (roundDone) {
            if (currentExpert == previousExpert) {
                bullyFollow->roundUpdate(happyRound, forgiveness, stringToCommunicate);
            }
            //printf("@@@@@@@@@@@@@@@should introduce\n");
            //bullyFollow->Introduce(currentExpert, previousExpert, ja_1, ja_2, myTurn, iaccept, stringToCommunicate);
            bullyFollow->Introduce(newExpert, forgiveness, ja_1, ja_2, myTurn, iaccept, notrust, notfairo, stringToCommunicate);
        }
        else {
            //printf("round NOT done\n");
        }
    }
    
    //printf("doner\n");
    
    if (roundDone) {
        if (forgiveness) {
            currentlyGuilty = false;
            forgiveness = false;
        }
        happyRound = false;
        bothBetter = false;
        theresmore = false;
        iaccept = false;
        notrust = false;
        notfairo = false;
        associateDecreased = associateIncreased = imIncreased = imDecreased = false;
    }
    
    if (silentTreatment)
        strcpy(stringToCommunicate, "");
}

void CommAgent::parseMsg(char buf[1024]) {
    char *tkn;
    
    //printf("Message: %s\n", buf);
    
    tkn = strtok(buf, " ");
    roundDone = false;
    shoulda = false;
    strcpy(shouldaMsg, "");
    bothBetter = false;
    theresmore = false;
    iaccept = false;
    notrust = false;
    notfairo = false;
    while (true) {
        //printf("kind: %s\n", tkn);
        if (!strcmp(tkn, "*"))
            break;
        else if (!strcmp(tkn, "Event")) {
            //printf("Event\n");
            tkn = strtok(NULL, " ");
            setEvent(atoi(tkn));
        }
        else if (!strcmp(tkn, "Expert")) {
            tkn = strtok(NULL, " ");
            currentExpert = atoi(tkn);
            newExpert = true;
            //printf("Expert: %i\n", currentExpert);
        }
        else if (!strcmp(tkn, "Round")) {
            //printf("Round\n");
            tkn = strtok(NULL, " ");
            roundDone = true;
            previousExpert = currentExpert;
            currentRound = atoi(tkn);
            newExpert = false;
            //associateDecreased = associateIncreased = imIncreased = imDecreased = false;
        }
        else if (!strcmp(tkn, "Assess")) {
            //printf("Assess\n");
            tkn = strtok(NULL, " ");
            int assessment = atoi(tkn);
            tkn = strtok(NULL, " ");
            setAssessment(assessment, atoi(tkn));
        }
        else if (!strcmp(tkn, "String")) {
            //printf("String\n");
            tkn = strtok(NULL, " ");
            shoulda = true;
            strcpy(shouldaMsg, "");
            
            tkn = strtok(NULL, " ");
            while (strcmp(tkn, "$")) {
                strcat(shouldaMsg, tkn);
                strcat(shouldaMsg, " ");
                tkn = strtok(NULL, " ");
            }
            
            //printf("shouldaMsg: %s\n", shouldaMsg);
        }
        else if (!strcmp(tkn, "JAction")) {
            //printf("JAction\n");
            tkn = strtok(NULL, " ");
            strcpy(ja_1, tkn);
            tkn = strtok(NULL, " ");
            strcpy(ja_2, tkn);

            //printf("ja's: %s %s\n", ja_1, ja_2);
        }
        else {
            printf("command %s not found\n", tkn);
        }
        
        tkn = strtok(NULL, " ");
    }
    
    if (tipo == EMOTION_PLANNER_TYPE) {
        //if ((currentExpert != previousExpert) && roundDone && (currentExpert != 0)) {
        if (newExpert && roundDone && (currentExpert != 0)) {
            char buf[1024];

            if ((currentExpert > 2) && (abs(currentExpert - previousExpert) != 3)) {
                if (currentExpert != 1) {
                    sprintf(buf, "%i;", CHANGE_O_HEART);
                    strcpy(stringToCommunicate, buf);
                    //strcat(stringToCommunicate, buf);
                }
            }

            if (bothBetter) {
                //strcpy(buf, "We can both do better than this. ");
                sprintf(buf, "%i;", DOBETTER);
                strcat(stringToCommunicate, buf);
            }
            
            forgiveness = false;
            
            //printf("------ not guilty ------\n");
            currentlyGuilty = false;
        }
    }
}

void CommAgent::setEvent(int evnt) {
    //printf("Event: %i\n", evnt);

    switch (evnt) {
        case 1: imIncreased = true; break;
        case 2: imDecreased = true; break;
        case 3: associateIncreased = true; break;
        case 4: associateDecreased = true; break;
        case 5: happyRound = false; break;
        case 6: happyRound = true; break;
        case 7: happyExpert = false; break;
        case 8: happyExpert = true; break;
        case 9: break; //printf("not sure what to do with event 11\n"); break;
        case 10: break;
        case 11: break; //printf("not sure what to do with event 11\n"); break;
    }
    
    //printf("associateDecreased: %i\n", (int)associateDecreased);
}

void CommAgent::setAssessment(int ment, int cur) {
    //printf("Assessment: %i %i\n", ment, cur);

    switch (ment) {
        case 1:
        case 2: if (cur == 0)
                    myTurn = false;
                else
                    myTurn = true;
                break;
        case 3: currentlyGuilty = true; break;
        case 4: forgiveness = true; break;
        case 5: bothBetter = true; break;
        case 6: theresmore = true; break;
        case 7: iaccept = true; break;
        case 8: if (distrustCount < 2)
                    notrust = true;
                distrustCount ++;
                printf("---------- got the NO-TRUST message (%i) -------------\n", distrustCount);
                break;
        case 9: if (notfairCount < 2)
                    notfairo = true;
                printf("---------- got the NO-FAIR message (%i) -------------\n", notfairCount);
                notfairCount ++;
                break;
    }
}
