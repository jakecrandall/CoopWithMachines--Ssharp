#include "Bouncer.h"

extern bool theRealRobot;

Bouncer::Bouncer() {
    printf("incomplete Bouncer constructor\n");
    exit(1);
}

Bouncer::Bouncer(int _commType) {
    commType = _commType;
    
    lowCount = highCount = 0;
    firstTime = true;
    
    if (!theRealRobot) {
        strcpy(intros[0], "I will not let you cheat me. ");
        strcpy(intros[1], "I insist on equal payoffs. ");
        strcpy(intros[2], "I\\'ll play fair if you\\'ll play fair. ");
        
//        if (commType == EMOTION_PLANNER_TYPE) {
            strcpy(lows[0], "You forced my hand. ");
            strcpy(lows[1], "The amount of points we get is up to you. ");
            strcpy(lows[2], "Thats what you get. ");
            strcpy(lows[3], "Do not threaten me. ");
/*        }
        else {
            strcpy(lows[0], "Not good enough.");
            strcpy(lows[1], "Fiddle sticks.");
            strcpy(lows[2], "Darn it.");
            strcpy(lows[3], "I must be cursed.");
        }
*/
        strcpy(highs[0], "That was fair. ");
        strcpy(highs[1], "Good. ");
        strcpy(highs[2], "Thats what I\\'m talkin about. ");
        strcpy(highs[3], "I like this. ");
    }
    else {
        strcpy(intros[0], "I will not let you cheat me.");
        strcpy(intros[1], "I insist on equal payoffs.");
        strcpy(intros[2], "I'll play fair if you'll play fair.");
        
//        if (commType == EMOTION_PLANNER_TYPE) {
            strcpy(lows[0], "You forced my hand.");
            strcpy(lows[1], "The amount of points we get is up to you.");
            strcpy(lows[2], "Thats what you get.");
            strcpy(lows[3], "Do not threaten me.");
/*        }
        else {
            strcpy(lows[0], "You forced my hand.");
            strcpy(lows[1], "The amount of points we get is up to you.");
            strcpy(lows[2], "Thats what you get.");
            strcpy(lows[3], "Do not threaten me.");
        }*/
        
        strcpy(highs[0], "That was fair.");
        strcpy(highs[1], "Good.");
        strcpy(highs[2], "Thats what I'm talkin about");
        strcpy(highs[3], "I like this.");
    }
}

Bouncer::~Bouncer() {
}

void Bouncer::roundUpdate(bool _high, char stringToCommunicate[1024]) {
    if (_high) {
        highPayout(stringToCommunicate);
        highCount ++;
    }
    else {
        lowPayout(stringToCommunicate);
        lowCount ++;
    }
}

void Bouncer::Introduce(char stringToCommunicate[1024]) {
    char buf[1024];
    
    if (commType == EMOTION_PLANNER_TYPE) {
        if (firstTime) {
            sprintf(buf, "%s %s %s  ", intros[0], intros[1], intros[2]);
        }
        else {
            sprintf(buf, "%s ", intros[rand() % NUM_INTROS]);
        }
        
        //printf("system: %s", buf);
        //system(buf);
        strcat(stringToCommunicate, buf);
    
        firstTime = false;
    }
    
    highCount = highCount / 3;
    lowCount = lowCount / 3;
}

void Bouncer::lowPayout(char stringToCommunicate[1024]) {
    //printf("in lowPayout\n");
    
    double notsilent = 1.0 / (1.0 + (lowCount / 5.0));
    //printf("probability of silence: %lf\n", 1.0 - notsilent);
    double num = rand() / (double)RAND_MAX;
    //printf("num = %lf\n", num);
    
    if (num > (1.0 - notsilent)) {
        char buf[1024];
        if (commType == EMOTION_PLANNER_TYPE)
            sprintf(buf, "%s %s  ", lows[rand() % NUM_LOWS], intros[rand() % NUM_INTROS]);
        else
            sprintf(buf, "%s ", lows[rand() % NUM_LOWS]);
        
            //printf("system: %s", buf);
            //system(buf);
            strcat(stringToCommunicate, buf);
        //}
        //else
        //    sprintf(buf, "say %s\n", lows[rand() % NUM_LOWS]);
    }
}

void Bouncer::highPayout(char stringToCommunicate[1024]) {
    //printf("in highPayout\n");
    
    double notsilent = 1.0 / (1.0 + (highCount / 2.0));
    //printf("probability of silence: %lf\n", 1.0 - notsilent);
    double num = rand() / (double)RAND_MAX;
    //printf("num = %lf\n", num);
    
    if (num > (1.0 - notsilent)) {
        char buf[1024];
        sprintf(buf, "%s  ", highs[rand() % NUM_HIGHS]);
        
        //printf("system: %s", buf);
        //system(buf);
        strcat(stringToCommunicate, buf);
        system(buf);
    } 
}
