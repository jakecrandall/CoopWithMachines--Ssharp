#include "Br.h"

extern bool theRealRobot;

Br::Br() {
    printf("incomplete BR constructor\n");
    exit(1);
}

Br::Br(int _commType) {
    commType = _commType;
    first = true;
    count = 0;
    
    if (!theRealRobot) {
        strcpy(lows[0], "I must be cursed. ");
        strcpy(lows[1], "Not good enough for me. ");
        strcpy(lows[2], "Darn. ");
        
        strcpy(highs[0], "Good for me. ");
        strcpy(highs[1], "Satisfactory. ");
        strcpy(highs[2], "Nice! ");
    }
    else {
        strcpy(lows[0], "I must be cursed.");
        strcpy(lows[1], "Not good enough for me.");
        strcpy(lows[2], "Darn.");
        
        strcpy(highs[0], "Good for me.");
        strcpy(highs[1], "Satisfactory.");
        strcpy(highs[2], "Nice");
    }
}

Br::~Br() {
}

void Br::Introduce(char stringToCommunicate[1024]) {
    if (first) {
        
        //system("say Hello.  Good to meet you.");
        //strcat(stringToCommunicate, "Hello.  Good to meet you. ");
    }
    
    first = false;
}

void Br::roundUpdate(bool happy, char stringToCommunicate[1024]) {
    
    double notsilent = 1.0 / (1.0 + (count / 3.0));
    //printf("probability of silence: %lf\n", 1.0 - notsilent);
    double num = rand() / (double)RAND_MAX;
    //printf("num = %lf\n", num);
    
    if (num > (1.0 - notsilent)) {
        char buf[1024];
        
        if (happy) {
            //sprintf(buf, "%s ", highs[rand() % BR_NUM_HIGHS]);
            sprintf(buf, "%i;", EXCELLENT);
            strcat(stringToCommunicate, buf);
        }
        else {
            //sprintf(buf, "%s ", lows[rand() % BR_NUM_LOWS]);
            //sprintf(buf, "%i;", CURSE_YOU);
        }
        
        //printf("system: %s", buf);
        //system(buf);
    }
    
    count = count + 1;
}
