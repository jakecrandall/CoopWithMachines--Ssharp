./Solver prisoners all mbrl megaExp3 500

./Solver prisoners all umbrl umbrl 500
./Solver prisoners all umbrl megaS++ 500
./Solver prisoners all umbrl megaExp3 500

./Solver prisoners all megaExp3 megaExp3 500

./Solver prisoners all megaS++ megaExp3 500
