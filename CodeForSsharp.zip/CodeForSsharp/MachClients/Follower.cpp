#include "Follower.h"

extern bool theRealRobot;
extern bool doTheSpecify;
extern bool yaDicho, yaDicho2;

Follower::Follower() {
    printf("incomplete Follower constructor");
    exit(1);
}

Follower::Follower(int _commType, bool _alternate, bool _bully) {
    commType = _commType;
    alternate = _alternate;
    bully = _bully;
    count = 0;
}

Follower::~Follower() {
}

//void Follower::Introduce(int currentExpert, int previousExpert, char ja_1[1024], char ja_2[1024], bool myTurn, bool _iaccept, char stringToCommunicate[1024]) {
void Follower::Introduce(bool newExpert, bool _forgiveness, char ja_1[1024], char ja_2[1024], bool myTurn, bool _iaccept, bool _notrust, bool _notfairo, char stringToCommunicate[1024]) {
    char buf[1024];
    
    printf("---------------- Follower Introduce (%i) ------------------\n", _notfairo);
    
    if (_iaccept) {
        sprintf(buf, "%i;", IACCEPT);
        strcpy(stringToCommunicate, buf);
        //strcat(stringToCommunicate, buf);
    }
    else if (_notrust && !yaDicho) {
        sprintf(buf, "%i;%i;", UNACCEPTABLE, NOTRUST);
        strcat(stringToCommunicate, buf);
        yaDicho = true;
    }
    else if (_notfairo && !yaDicho) {
        sprintf(buf, "%i;%i;", UNACCEPTABLE, NOTFAIR);
        strcat(stringToCommunicate, buf);
        yaDicho = true;
    }
    
    //if ((currentExpert != previousExpert)) {// && !bully) {
    if (newExpert || _forgiveness) {
        if (commType == EMOTION_PLANNER_TYPE) {
            //sprintf(buf, "%s ", intros[0]);
            if (!alternate && !yaDicho2) {
                sprintf(buf, "%i %s;", LETS_COOP, ja_1);
                strcat(stringToCommunicate, buf);
            }
            else {
                printf("Should say to take turns, but if I've already said it ... ");
                if (!yaDicho2) {
                    sprintf(buf, "%i %s %s;", TAKE_TURNS, ja_1, ja_2);
                    strcat(stringToCommunicate, buf);
                }
                
                if (doTheSpecify) {
                    if (myTurn)
                        sprintf(buf, "%i %s;", SPECIFY, ja_2);
                    else
                        sprintf(buf, "%i %s;", SPECIFY, ja_1);
                    strcat(stringToCommunicate, buf);
                }
            }
            yaDicho2 = true;
        }
        
        if (newExpert)
            count = 0;
    }
    else if (alternate && (count < 5)) {
        if (commType == EMOTION_PLANNER_TYPE) {
            if (doTheSpecify) {
                if (myTurn)
                    sprintf(buf, "%i %s;", SPECIFY, ja_2);
                else
                    sprintf(buf, "%i %s;", SPECIFY, ja_1);
                strcat(stringToCommunicate, buf);
                
                //printf("************* follower: set the dicho = true\n");
                //yaDicho2 = true;
            }
        }
    }
    
    //printf("count = %i\n", count);
    if ((count == 5) && (commType == EMOTION_PLANNER_TYPE)) {
        //sprintf(buf, "%s ", intros[7]);
        sprintf(buf, "%i;", SWEET);
        strcat(stringToCommunicate, buf);
    }
    
    
    count = count + 1;
}

void Follower::roundUpdate(bool happyRound, bool forgiveness, char stringToCommunicate[1024]) {
    char buf[1024];
    
    //lowered = false;
    if (happyRound && (count < 4)) {
        //sprintf(buf, "%s ", happythoughts[rand() % 4]);
        if (!yaDicho and !yaDicho2) {
            sprintf(buf, "%i;", EXCELLENT);
            strcat(stringToCommunicate, buf);
        }
    }
/*
    if (forgiveness) {
        printf("say I forgive you.\n");
        system("say I forgive you.\n");
        
        if (!bully) {
            sprintf(buf, "say %s", intros[1]);
            printf("%s", buf);
            system(buf);
        }
        else {
            sprintf(buf, "say But %s", intros[8]);
            printf("%s", buf);
            system(buf);
        }
        
        //if (alternate) {
        if (count > 3)
            count = 3;
        //}
    }*/
}

void Follower::moveEvent(bool shoulda, char shouldaMsg[1024], bool _heLowered, bool _guilty, char stringToCommunicate[1024]) {
    char buf[1024];
    
    if (shoulda) {
        //sprintf(buf, "%s %s%s. %s ", defects[1 + rand() % 4], defects[0], shouldaMsg, defects[5 + rand() % 3]);
        //sprintf(buf, "%i;%i %c;%i;", BETRAYED+(rand() % 2), I_THOUGHT, shouldaMsg[0], NOT_FRIENDS+(rand() % 2));
        if (rand() % 2)
            sprintf(buf, "%i;", BETRAYED);
        else
            sprintf(buf, "%i;", CURSE_YOU);
        strcat(stringToCommunicate, buf);
        
        if (count > 2)
            count = 2;
    }
    
    
    if (_guilty and (count > 2))
        count = 2;
}
