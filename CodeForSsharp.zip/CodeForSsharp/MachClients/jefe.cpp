#include "jefe.h"


//extern void addMessage(char msg[1024], int _origin, int _lineHeight);
//extern char blank[1024];

//extern char nomlogger[1024];

jefe::jefe() {
    printf("incomplete jefe constructor\n");
    exit(1);
}

jefe::jefe(const char *nombre, int _me, MarkovGame *_mg, double _lambda) {
    int i;
    
    me = _me;
    lambda = _lambda;
    comms = new CommAgent(NONE_TIPO, 4000, me, 0);
    
    t = 0;
    experto = -1;
    cycled = false;
    
    cycleFull = true;
    
    ab = new mega(_mg, me, false, comms, lambda);
    ab->computeAllExperts(lambda, false, true);
    
    ab->determineHighLevelActions();
    
    satisficingExperts = new bool[ab->numExperts];
    for (i = 0; i < ab->numExperts; i++)
        satisficingExperts[i] = true;
    numSatExperts = 1;
    
    double highval = -99999, lowval = 99999;
    for (i = 3; i < ab->numExperts; i++) {
        if (highval < ab->xprts[i]->barR[me])
            highval = ab->xprts[i]->barR[me];
        if (lowval > ab->xprts[i]->barR[me])
            lowval = ab->xprts[i]->barR[me];
    }
    //printf("highval = %lf; lowval = %lf\n", highval, lowval);
    
    //if (!strcmp(nombre, "S++")) {
    //    learner = new a(_me, _lambda, ab->numExperts, highval, lowval, _mg->states[0]->mm[me]->mv);//   ab->xprts[0]->barR[me]);
    //    cycleFull = false;
    //}
    if (!strcmp(nombre, "exp3w") || !strcmp(nombre, "exp3"))
        learner = new Exp3(me, (int)_lambda, 0.99, ab->numExperts, highval, 0.0);
    //else if (!strcmp(nombre, "eee++"))
    //    learner = new eee(_me, _lambda, ab->numExperts);
    //    else if (!strcmp(nombre, "ucbw++"))
    //        learner = new ucb(_me, _lambda, ab->numExperts);
    else {
        printf("expert learner not found\n");
        exit(1);
    }
    
    //setAspirationHigh();
    setAspirationFolkEgal();
    //setAspirationHighestEnforceable();
	mu = 0.0;
    
    alwaysMM = false;
    permissibleLoss = 500.0;
    
    lowAspiration = 1.0;
    
    lastState = NULL;
    rPayout[0] = rPayout[1] = 0.0;
    
    //strcpy(myMessage, "");
    
    //realbad = false;
    previousPayoffs[0] = previousPayoffs[1] = lastSegmentScore = -99999;
    for (i = 0; i < 10; i++) {
        payoffHistory[0][i] = -1.0;
        payoffHistory[1][i] = -1.0;
    }
    
    
    oldExpert = -1;
    
    tau = 0;
    latestJacts[0][0] = latestJacts[1][0] = -1;
    
    somethingBetter = false;
    
    newSelection();
    
    //char buf[1024];
    //sprintf(buf, "%s_%i.txt", nomlogger, me);
    //fpExpert = fopen(buf, "w");
}

jefe::~jefe() {
    delete learner;
    delete satisficingExperts;
    delete ab;
    delete comms;
    
    //fflush(fpExpert);
    //fclose(fpExpert);
}

int jefe::Move(GameEngine *ge) {
    
    
    //if (cycled) {
    //    newSelection();
    //    cycled = false;
    //}
    ge->getValidActions(lastValidActs[0], 0);
    ge->getValidActions(lastValidActs[1], 1);
    lastState = ge->getState(ab->mg, lastValidActs[0], lastValidActs[1]);
    /*
     int i, j;
     for (i = 0; i < lastState->numActions[me]; i++) {
     printf("%.2lf\t", lastState->Qbr[i]);
     }
     printf("\nbrVal = %.2lf\n\n", lastState->Vbr);
     */
    
    
    int b = ab->xprts[experto]->Move(lastState, previousPayoffs, me);
    int a = ge->convertIt(b, lastValidActs[me], NUMACTIONS*2);
    
    corA = -1;
    if ((ab->xprts[experto]->tipo == FOLLOWER) || (ab->xprts[experto]->tipo == LEADER) || (ab->xprts[experto]->tipo == LEADER2)) {
        int c = lastState->qsets[ab->xprts[experto]->strat[ab->xprts[experto]->currentStep]]->correctA(1-me);
        corA = ge->convertIt(c, lastValidActs[me], NUMACTIONS*2);
    }
    
    fprintf(fpExpert, "%i: %s\n", t, ab->xprts[experto]->dcode);
    
    return a;
}

void jefe::newSelection() {
    //printf("entering newSelection()\n"); fflush(stdout);
    
    oldExpert = experto;
    
    resetCycle();
    
    determineSatisficingExperts();
    
    int i;
    numSatExperts = 0;
    for (i = 0; i < ab->numExperts; i++) {
        if (satisficingExperts[i])
            numSatExperts ++;
    }
    
    //printf("numSatExperts: %i\n", numSatExperts);
    //printf("considering a strategy switch ... ");
    //if (t != 0)
        experto = learner->select(satisficingExperts);
    //else
    //    experto = 1;
    //printf("picked %i (tipo: %i)\n", experto, ab->xprts[experto]->tipo);
    
    if ((experto > 1) && (experto != oldExpert)) {
        //printf("%i vs %i\n", experto, oldExpert);
        //if (strcmp(ab->xprts[experto]->description,"")) {
        if (ab->xprts[experto]->descriptionLen > 0) {
            //addMessage(blank, 5, -1);
            if (oldExpert >= 0) {
                char buf[1024];
                if (ab->xprts[oldExpert]->guilt > 0.0001) {
                    //strcpy(buf, "On second thought, I'll forgive you for now.|");
                    //addMessage(buf, 15, me);
                    //comms->postMessage(buf);
//                    comms->postMessage(21);
//                    if (somethingBetter)
//                        comms->postMessage(33);
                }
                else {
                    //strcpy(buf, "I've changed my mind.|");
                    //addMessage(buf, 15, me);
                    //comms->postMessage(buf);
//                    if (somethingBetter)
//                        comms->postMessage(33);
//                    else
//                        comms->postMessage(22);
                }
            }
            //addMessage(ab->xprts[experto]->description, 15, me);
            //comms->postMessage(ab->xprts[experto]->description);
            //printf("new selection call\n");
            //ab->xprts[experto]->currentStepMessage(me);
            
            //addMessage(ab->xprts[experto]->currentMessage, 15, me);
//            for (int l = 0; l < ab->xprts[experto]->descriptionLen; l++) {
//                comms->postMessage(ab->xprts[experto]->description[l]);
//            }
        }
        
        ab->xprts[experto]->reset(previousPayoffs, me);
        ab->xprts[experto]->currentStepMessage(me);
        
        //latestJacts[0][0] = -1;
        //latestJacts[1][0] = -1;
    }
    else if ((experto == 0) || (experto == 1)) {
//        addMessage(blank, 5, -1);
//        for (int l = 0; l < ab->xprts[experto]->descriptionLen; l++) {
//            comms->postMessage(ab->xprts[experto]->description[l]);
//        }
    }
}

int jefe::moveUpdate(GameEngine *ge, int actions[2], double dollars[2]) {
    int acts[2];
    ge->deduceActions(acts, actions, lastValidActs);
    
    //if (me == 0)
    //    printf("r = %lf\n", ge->getCurrentReward(0));
    
    rPayout[0] += dollars[0];
    rPayout[1] += dollars[1];
    
    ge->getValidActions(lastValidActs[0], 0);
    ge->getValidActions(lastValidActs[1], 1);
    State* sprime = ge->getState(ab->mg, lastValidActs[0], lastValidActs[1]);
    
    ab->moveUpdate(lastState, sprime, acts, experto, rPayout, learner->aspiration, corA);
    
    return 0;
}


int jefe::roundUpdate() {
    
    int i;
    for (i = 9; i > 0; i--) {
        payoffHistory[0][i] = payoffHistory[0][i-1];
        payoffHistory[1][i] = payoffHistory[1][i-1];
    }
    previousPayoffs[0] = payoffHistory[0][0] = rPayout[0];
    previousPayoffs[1] = payoffHistory[1][0] = rPayout[1];
    
    // update the payoffs for this "cycle"
	R += rPayout[me];
    Rnot += rPayout[1-me];
	mu += rPayout[me];
    
    //printf("Rtally = %lf\n", R);
    
    ab->roundUpdate(rPayout);
    latestJacts[0][tau+1] = ab->highestInd[0];
    latestJacts[1][tau+1] = ab->highestInd[1];
    
    //for (i = 0; i < tau+2; i++)
    //    printf("%i, %i\n", latestJacts[0][i], latestJacts[1][i]);
    //printf("\n"); fflush(stdout);
    
    //printf("Rresult (%i): %.2lf, %.2lf\n", me, rPayout[0], rPayout[1]);
    bool heldTrue = false;
    if ((ab->xprts[experto]->tipo == FOLLOWER) || (ab->xprts[experto]->tipo == LEADER) || (ab->xprts[experto]->tipo == LEADER2)) {
        if (ab->lastActions[1-me][ab->xprts[experto]->strat[ab->xprts[experto]->currentStep]+2] == 1) {
            //printf("held true\n");
            heldTrue = true;
        }
    }
    ab->xprts[experto]->Update(rPayout, me, learner->aspiration, heldTrue, learner->aspiration);
    
    rPayout[0] = rPayout[1] = 0.0;
    
	t++;
	tau ++;
    
    //if ((tau >= ab->xprts[experto]->cycleLen) && (ab->xprts[experto]->guilt == 0))
    if (!cycleFull) {
        //printf("this question ... ");
        if (repeatJaction()) {
            //printf("yes\n");
            cycled = true;
        }
        //printf("no\n");
    }
    else {
        //printf("%i tau = %i; cLen = %i\n", me, tau, ab->xprts[experto]->cycleLen);
        if (tau >= ab->xprts[experto]->cycleLen)
            cycled = true;
    }
    
    //strcpy(myMessage, ab->xprts[experto]->currentMessage);
    int myMessage = ab->xprts[experto]->currentMessage;
    
	if (cycled) {
        lastSegmentScore = R / tau;
/*        if (R / tau < ab->mg->startStates[0]->mm[me]->mv) {
            if (ab->xprts[experto]->tipo == FOLLOWER)
                realbad = true;
        }
        else {
            if ((R / tau >= learner->aspiration) && (ab->xprts[experto]->guilt < 0.00001)) {
                //strcpy(myMessage, "I'm happy with this.|");
                myMessage = 20;
            }
            
            realbad = false;
        }
*/
        //    strcpy(myMessage, "I think we could do better than this.  I might try something different.");
        
		learner->update(R / tau, tau);
		//if (((ab->mg->startStates[0]->mm[me]->mv * t) - mu) > permissibleLoss) {
        //    printf("%i: I'm losing!!!!! mu = %lf; mv*t = %lf; permissibleLoss = %lf\n", me, mu, ab->mg->startStates[0]->mm[me]->mv * t, permissibleLoss);
		//	alwaysMM = true;
        //}
        //printf("aspiration_%i=%.2lf\n", me,learner->aspiration);
    }
    
    if (learner->aspiration < lowAspiration)
        lowAspiration = learner->aspiration;
    
    //printf("a%i=%lf>", me,learner->aspiration);
    //if (strcmp(myMessage,"")) {
    
    if (cycled) {
        // check to see if we both could do better
        somethingBetter = isSomethingBetter(R/tau,Rnot/tau);
        
        newSelection();
        cycled = false;
        
        if (((R/tau) > (ab->xprts[experto]->barR[me]-ab->xprts[experto]->deltaMax)) || ((Rnot/tau) > (ab->xprts[experto]->barR[1-me]-ab->xprts[experto]->deltaMax))) {
            somethingBetter = false;
        }
        
        if (oldExpert == experto) {
            //if (myMessage > 0) {
                //addMessage(blank, 5, -1);
                //addMessage(myMessage, 15, me);
//                comms->postMessage(myMessage);
            //    if (ab->xprts[experto]->describeExpert) {
//                    for (int l = 0; l < ab->xprts[experto]->descriptionLen; l++) {
//                        comms->postMessage(ab->xprts[experto]->description[l]);
//                    }
                    
            //        ab->xprts[experto]->describeExpert = false;
            //    }
            //}
            if (ab->xprts[experto]->guilt < 0.00001)
                ab->xprts[experto]->currentStepMessage(me);
        }
    }
    else {
        //if (myMessage > 0) {
            //addMessage(blank, 5, -1);
            //addMessage(myMessage, 15, me);
//            comms->postMessage(myMessage);
        //    if (ab->xprts[experto]->describeExpert) {
//                for (int l = 0; l < ab->xprts[experto]->descriptionLen; l++) {
//                    comms->postMessage(ab->xprts[experto]->description[l]);
//                }
                
        //        ab->xprts[experto]->describeExpert = false;
        //    }
        //}
        if (ab->xprts[experto]->guilt < 0.00001)
            ab->xprts[experto]->currentStepMessage(me);
    }
    
    return 0;
}

bool jefe::isSomethingBetter(double _mine, double _his) {
    int i;
    
    //printf("mine = %lf; his = %lf\n", _mine, _his);
    for (i = 0; i < ab->numExperts; i++) {
        //printf("\t%lf, %lf\n", (ab->xprts[i]->barR[me]-ab->xprts[i]->deltaMax), (ab->xprts[i]->barR[1-me]-ab->xprts[i]->deltaMax));
        if ((_mine < (ab->xprts[i]->barR[me]-ab->xprts[i]->deltaMax)) && (_his < (ab->xprts[i]->barR[1-me]-ab->xprts[i]->deltaMax))) {
            //printf("somethingBetter = true\n");
            return true;
        }
    }
    //printf("somethingBetter = false\n");
    
    return false;
}

void jefe::determineSatisficingExperts() {
    int i;
    for (i = 0; i < ab->numExperts; i++)
        satisficingExperts[i] = true;
}

void jefe::resetCycle() {
    
	R = 0.0;
    Rnot = 0.0;
    
    if (!cycleFull) {
        latestJacts[0][0] = latestJacts[0][tau];
        latestJacts[1][0] = latestJacts[1][tau];
    }
    
   	tau = 0;
    
    /*	for (int i = 0; i < numStates; i++)
     beenThere[i] = false;
     
     if (estado >= 0)
     beenThere[estado] = true;*/
}
/*
 double jefe::pay(int me, int sol) {
 int a0, a1;
 
 a0 = sol / A[1];
 a1 = sol % A[1];
 
 //printf("a0 = %i\n", a0);
 //printf("a1 = %i\n", a1);
 
 return M[me][a0][a1];
 }
 */
void jefe::setAspirationHigh() {
    if (ab->numExperts == 3) {
        learner->aspiration = ab->mg->startStates[0]->mm[me]->mv;
        printf("no good expert\n");
        return;
    }
    
	int i, j, index = -1;
	double high = ab->mg->startStates[0]->mm[me]->mv;
	int s;
    
	for (i = 3; i < ab->numExperts; i++) {
        if (ab->xprts[i]->barR[me] > high) {
            high = ab->xprts[i]->barR[me];
            index = i;
        }
	}
    
	learner->aspiration = high;
	printf("%i: initial aspiration level = %.3lf\n", me, learner->aspiration);
}

void jefe::setAspirationFolkEgal() {
    if (ab->numExperts == 3) {
        learner->aspiration = ab->mg->startStates[0]->mm[me]->mv;
        printf("no good expert\n");
        return;
    }
    
	int i, j, index = -1;
	double high = 0.0/*mnmx[me]->mv*/, theMin;
	int s;
    
	for (i = 3; i < ab->numExperts; i++) {
        theMin = ab->xprts[i]->barR[me];
        if (theMin > ab->xprts[i]->barR[1-me])
            theMin = ab->xprts[i]->barR[1-me];
        
        //printf("theMin = %lf\n", theMin);
        
        if (theMin > high) {
            high = theMin;
            index = i;
        }
	}
    
    //printf("index = %i\n", index);
    //fflush(stdout);
    
	learner->aspiration = ab->xprts[index]->barR[me];
    if (learner->aspiration < ab->mg->startStates[0]->mm[me]->mv)
        learner->aspiration = ab->mg->startStates[0]->mm[me]->mv;
	printf("%i: initial aspiration level = %.3lf\n", me, learner->aspiration);
}

void jefe::setAspirationHighestEnforceable() {
    if (ab->numExperts == 3) {
        learner->aspiration = ab->mg->startStates[0]->mm[me]->mv;
        printf("no good expert\n");
        return;
    }
    
	int i, j, index = -1;
	double high = 0.0/*mnmx[me]->mv*/, val;
	int s;
    
    //printf("REcount = %i\n", REcount);
    //fflush(stdout);
    
	for (i = 3; i < ab->numExperts; i++) {
        if (((ab->xprts[i]->tipo == LEADER) || (ab->xprts[i]->tipo == LEADER2)) && (ab->xprts[i]->barR[me] > high)) {
            high = ab->xprts[i]->barR[me];
            index = i;
        }
	}
    
    //printf("index = %i\n", index);
    //fflush(stdout);
    if (index == -1) {
        printf("nothing is enforceable\n"); fflush(stdout);
        setAspirationFolkEgal();
    }
    else {
        learner->aspiration = ab->xprts[index]->barR[me];
        if (learner->aspiration < ab->mg->startStates[0]->mm[me]->mv)
            learner->aspiration = ab->mg->startStates[0]->mm[me]->mv;
        printf("%i: initial aspiration level = %.3lf\n", me, learner->aspiration);
    }
}

bool jefe::repeatJaction() {
    int i;
    
    //printf("tau = %i (%i, %i)\n", tau, latestJacts[0][tau], latestJacts[1][tau]);
    for (i = 0; i < tau; i++) {
        //printf("%i, %i\n", latestJacts[0][i], latestJacts[1][i]);
        if ((latestJacts[0][i] == latestJacts[0][tau]) && (latestJacts[1][i] == latestJacts[1][tau])) {
            //printf("repeated\n");
            return true;
        }
    }
    
    //printf("i = %i\n", i);
    
    return false;
}
