./Solver gridwar1 all friend cfru 500
./Solver gridwar1 all cfru friend 500

./Solver gridwar1 all maxmin cfru 500
./Solver gridwar1 all cfru maxmin 500

./Solver gridwar1 all folk cfru 500
./Solver gridwar1 all cfru folk 500

./Solver gridwar1 all bully cfru 500
./Solver gridwar1 all cfru bully 500

./Solver gridwar1 all bouncer cfru 500
./Solver gridwar1 all cfru bouncer 500

./Solver gridwar1 all mbrl cfru 500
./Solver gridwar1 all cfru mbrl 500

./Solver gridwar1 all umbrl cfru 500
./Solver gridwar1 all cfru umbrl 500

./Solver gridwar1 all cfru cfru 500
./Solver gridwar1 all cfru megaS++ 500
./Solver gridwar1 all megaS++ cfru 500
./Solver gridwar1 all cfru megaExp3 500
./Solver gridwar1 all megaExp3 cfru 500
