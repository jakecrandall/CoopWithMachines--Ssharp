./Solver prisoners all friend megaS++ 500
./Solver prisoners all friend megaExp3 500

./Solver prisoners all folk folk 500
./Solver prisoners all folk bully 500
./Solver prisoners all folk bouncer 500
./Solver prisoners all folk mbrl 500
./Solver prisoners all folk umbrl 500
./Solver prisoners all folk megaS++ 500
./Solver prisoners all folk megaExp3 500

./Solver prisoners all bully bully 500
./Solver prisoners all bully bouncer 500
./Solver prisoners all bully mbrl 500
./Solver prisoners all bully umbrl 500
./Solver prisoners all bully megaS++ 500
./Solver prisoners all bully megaExp3 500

./Solver prisoners all bouncer bouncer 500
./Solver prisoners all bouncer mbrl 500
./Solver prisoners all bouncer umbrl 500
./Solver prisoners all bouncer megaS++ 500
./Solver prisoners all bouncer megaExp3 500

./Solver prisoners all mbrl mbrl 500
./Solver prisoners all mbrl umbrl 500
./Solver prisoners all mbrl megaS++ 500
./Solver prisoners all mbrl megaExp3 500

./Solver prisoners all umbrl umbrl 500
./Solver prisoners all umbrl megaS++ 500
./Solver prisoners all umbrl megaExp3 500

./Solver prisoners all megaS++ megaS++ 500
./Solver prisoners all megaS++ megaExp3 500

./Solver prisoners all megaExp3 megaExp3 500
